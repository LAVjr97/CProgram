/****************************************************************************
** Meta object code from reading C++ file 'mainwindow.h'
**
** Created by: The Qt Meta Object Compiler version 68 (Qt 6.7.2)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../../mainwindow.h"
#include <QtGui/qtextcursor.h>
#include <QtCore/qmetatype.h>

#include <QtCore/qtmochelpers.h>

#include <memory>


#include <QtCore/qxptype_traits.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'mainwindow.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 68
#error "This file was generated using the moc from 6.7.2. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

#ifndef Q_CONSTINIT
#define Q_CONSTINIT
#endif

QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
QT_WARNING_DISABLE_GCC("-Wuseless-cast")
namespace {

#ifdef QT_MOC_HAS_STRINGDATA
struct qt_meta_stringdata_CLASSMainWindowENDCLASS_t {};
constexpr auto qt_meta_stringdata_CLASSMainWindowENDCLASS = QtMocHelpers::stringData(
    "MainWindow",
    "showMainPage",
    "",
    "showDropOffPage",
    "showSearchPage",
    "showCustomerSearchResultsPage",
    "showNewCustomerPage",
    "showOrderLaundryPage",
    "showOrderDryCleanPage",
    "showOrderAlterationsPage",
    "showPickUpPage",
    "showCustomerSearchPagePU",
    "showOrderSearchPagePU",
    "showCustomerSearchResultsPU",
    "showOrderSearchResultsPU",
    "showEditOrderPage",
    "showOrderSearchPageEO",
    "showCustomerSearchPageEO",
    "showCustomerSearchResultsEO",
    "showOrderSearchResultsEO",
    "showAdminPage",
    "showItemsAndPricePage",
    "on_btnDropOff_clicked",
    "on_btnPickUp_clicked",
    "on_btnEditOrder_clicked",
    "on_btnAdmin_clicked",
    "on_btnLaundry_clicked",
    "on_btnDryClean_clicked",
    "on_btnAlterations_clicked",
    "on_btnCustomer_clicked",
    "on_btnReturn_clicked",
    "on_btnSaveDP_clicked",
    "on_btnOneRecieptDP_clicked",
    "on_btnTwoRecieptDP_clicked",
    "on_btnReturnCS_clicked",
    "on_btnNewCustomersCS_clicked",
    "on_btnReturn_3_clicked",
    "on_btnCreate_clicked",
    "on_btnReturnCSR_clicked",
    "on_btnSearchCS_clicked",
    "on_tableViewCSR_clicked",
    "QModelIndex",
    "index",
    "clearScreenNC",
    "on_btnLaundryReturn_clicked",
    "on_tableWidgetLaundryOptions_clicked",
    "on_btnDryCleanReturn_clicked",
    "on_tableWidgetDryCleanOptions_clicked",
    "on_btnAlterationsReturn_clicked",
    "on_tableWidgetAlterationsOptions_clicked",
    "on_btnCustomerPU_clicked",
    "on_btnOrderSearchPU_clicked",
    "on_btnSavePU_clicked",
    "on_btnReturnPU_clicked",
    "on_btnReturnCSPU_clicked",
    "on_btnSearchCSPU_clicked",
    "on_btnReturnOS_clicked",
    "on_btnSearchOrderOS_clicked",
    "on_btnReturnCSRPU_clicked",
    "on_tableViewCSRPU_clicked",
    "on_btnReturnOSR_clicked",
    "on_tableViewOSR_clicked",
    "on_btnCustomerEO_clicked",
    "on_btnOrderSearchEO_clicked",
    "on_btnSaveEO_clicked",
    "on_btnOneRecieptEO_clicked",
    "on_btnTwoRecieptEO_clicked",
    "on_btnReturnEO_clicked",
    "on_btnReturnOSEO_clicked",
    "on_btnSearchOrderEO_clicked",
    "on_btnReturnCSEO_clicked",
    "on_btnSearchCSEO_clicked",
    "on_btnReturnCSREO_clicked",
    "on_tableViewCSREO_clicked",
    "on_btnReturnOSREO_clicked",
    "on_tableViewOSREO_clicked",
    "on_btnReturnAP_clicked",
    "on_btnCIP_clicked",
    "on_btnExportData_clicked",
    "on_btnReturnCIP_clicked",
    "on_btnSaveCIP_clicked",
    "saveTableCIP",
    "std::vector<std::vector<std::pair<std::string,double>>>&",
    "prices",
    "std::vector<std::tuple<std::string,int,int>>&",
    "pos",
    "QTableWidget*",
    "tableWidget",
    "setUpCIPPage",
    "setUpTableWidgetsCIP",
    "clearScreenDP",
    "clearScreenPU",
    "clearScreenEO",
    "updateCOInformationDP",
    "updateCOInformationPU",
    "updateCOInformationEO",
    "setUpOptionsTables",
    "std::vector<std::vector<std::pair<std::string,double>>>",
    "std::vector<std::tuple<std::string,int,int>>",
    "tableWidgetOptions",
    "typ",
    "customerSearchPageSetUp",
    "QTableView*",
    "tableView",
    "QStandardItemModel*",
    "model",
    "QLineEdit*",
    "lineSearch",
    "setDate",
    "QDateTimeEdit*",
    "dp",
    "QDateEdit*",
    "pu",
    "saveModel",
    "saveTableView",
    "std::pair<size_t,std::vector<std::vector<std::tuple<std::string,int,do"
    "uble>>>>",
    "std::vector<std::vector<std::tuple<std::string,int,double>>>",
    "article",
    "pieceType",
    "size_t",
    "row",
    "updateModel",
    "updateTableView",
    "articles",
    "getTypeName",
    "std::string",
    "curRow",
    "articlePos",
    "getIndex",
    "calculateSize",
    "calculatePieceTotal",
    "createType",
    "curIndex",
    "newPiece",
    "increaseIndex",
    "removeItemPrice",
    "pieceI",
    "removeIndex",
    "saveAndPrint",
    "n",
    "p",
    "QCheckBox*",
    "b",
    "printReciept"
);
#else  // !QT_MOC_HAS_STRINGDATA
#error "qtmochelpers.h not found or too old."
#endif // !QT_MOC_HAS_STRINGDATA
} // unnamed namespace

Q_CONSTINIT static const uint qt_meta_data_CLASSMainWindowENDCLASS[] = {

 // content:
      12,       // revision
       0,       // classname
       0,    0, // classinfo
     104,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags, initial metatype offsets
       1,    0,  638,    2, 0x08,    1 /* Private */,
       3,    0,  639,    2, 0x08,    2 /* Private */,
       4,    0,  640,    2, 0x08,    3 /* Private */,
       5,    0,  641,    2, 0x08,    4 /* Private */,
       6,    0,  642,    2, 0x08,    5 /* Private */,
       7,    0,  643,    2, 0x08,    6 /* Private */,
       8,    0,  644,    2, 0x08,    7 /* Private */,
       9,    0,  645,    2, 0x08,    8 /* Private */,
      10,    0,  646,    2, 0x08,    9 /* Private */,
      11,    0,  647,    2, 0x08,   10 /* Private */,
      12,    0,  648,    2, 0x08,   11 /* Private */,
      13,    0,  649,    2, 0x08,   12 /* Private */,
      14,    0,  650,    2, 0x08,   13 /* Private */,
      15,    0,  651,    2, 0x08,   14 /* Private */,
      16,    0,  652,    2, 0x08,   15 /* Private */,
      17,    0,  653,    2, 0x08,   16 /* Private */,
      18,    0,  654,    2, 0x08,   17 /* Private */,
      19,    0,  655,    2, 0x08,   18 /* Private */,
      20,    0,  656,    2, 0x08,   19 /* Private */,
      21,    0,  657,    2, 0x08,   20 /* Private */,
      22,    0,  658,    2, 0x08,   21 /* Private */,
      23,    0,  659,    2, 0x08,   22 /* Private */,
      24,    0,  660,    2, 0x08,   23 /* Private */,
      25,    0,  661,    2, 0x08,   24 /* Private */,
      26,    0,  662,    2, 0x08,   25 /* Private */,
      27,    0,  663,    2, 0x08,   26 /* Private */,
      28,    0,  664,    2, 0x08,   27 /* Private */,
      29,    0,  665,    2, 0x08,   28 /* Private */,
      30,    0,  666,    2, 0x08,   29 /* Private */,
      31,    0,  667,    2, 0x08,   30 /* Private */,
      32,    0,  668,    2, 0x08,   31 /* Private */,
      33,    0,  669,    2, 0x08,   32 /* Private */,
      34,    0,  670,    2, 0x08,   33 /* Private */,
      35,    0,  671,    2, 0x08,   34 /* Private */,
      36,    0,  672,    2, 0x08,   35 /* Private */,
      37,    0,  673,    2, 0x08,   36 /* Private */,
      38,    0,  674,    2, 0x08,   37 /* Private */,
      39,    0,  675,    2, 0x08,   38 /* Private */,
      40,    1,  676,    2, 0x08,   39 /* Private */,
      43,    0,  679,    2, 0x08,   41 /* Private */,
      44,    0,  680,    2, 0x08,   42 /* Private */,
      45,    1,  681,    2, 0x08,   43 /* Private */,
      46,    0,  684,    2, 0x08,   45 /* Private */,
      47,    1,  685,    2, 0x08,   46 /* Private */,
      48,    0,  688,    2, 0x08,   48 /* Private */,
      49,    1,  689,    2, 0x08,   49 /* Private */,
      50,    0,  692,    2, 0x08,   51 /* Private */,
      51,    0,  693,    2, 0x08,   52 /* Private */,
      52,    0,  694,    2, 0x08,   53 /* Private */,
      53,    0,  695,    2, 0x08,   54 /* Private */,
      54,    0,  696,    2, 0x08,   55 /* Private */,
      55,    0,  697,    2, 0x08,   56 /* Private */,
      56,    0,  698,    2, 0x08,   57 /* Private */,
      57,    0,  699,    2, 0x08,   58 /* Private */,
      58,    0,  700,    2, 0x08,   59 /* Private */,
      59,    1,  701,    2, 0x08,   60 /* Private */,
      60,    0,  704,    2, 0x08,   62 /* Private */,
      61,    1,  705,    2, 0x08,   63 /* Private */,
      62,    0,  708,    2, 0x08,   65 /* Private */,
      63,    0,  709,    2, 0x08,   66 /* Private */,
      64,    0,  710,    2, 0x08,   67 /* Private */,
      65,    0,  711,    2, 0x08,   68 /* Private */,
      66,    0,  712,    2, 0x08,   69 /* Private */,
      67,    0,  713,    2, 0x08,   70 /* Private */,
      68,    0,  714,    2, 0x08,   71 /* Private */,
      69,    0,  715,    2, 0x08,   72 /* Private */,
      70,    0,  716,    2, 0x08,   73 /* Private */,
      71,    0,  717,    2, 0x08,   74 /* Private */,
      72,    0,  718,    2, 0x08,   75 /* Private */,
      73,    1,  719,    2, 0x08,   76 /* Private */,
      74,    0,  722,    2, 0x08,   78 /* Private */,
      75,    1,  723,    2, 0x08,   79 /* Private */,
      76,    0,  726,    2, 0x08,   81 /* Private */,
      77,    0,  727,    2, 0x08,   82 /* Private */,
      78,    0,  728,    2, 0x08,   83 /* Private */,
      79,    0,  729,    2, 0x08,   84 /* Private */,
      80,    0,  730,    2, 0x08,   85 /* Private */,
      81,    3,  731,    2, 0x08,   86 /* Private */,
      88,    0,  738,    2, 0x08,   90 /* Private */,
      89,    3,  739,    2, 0x08,   91 /* Private */,
      90,    0,  746,    2, 0x08,   95 /* Private */,
      91,    0,  747,    2, 0x08,   96 /* Private */,
      92,    0,  748,    2, 0x08,   97 /* Private */,
      93,    0,  749,    2, 0x08,   98 /* Private */,
      94,    0,  750,    2, 0x08,   99 /* Private */,
      95,    0,  751,    2, 0x08,  100 /* Private */,
      96,    3,  752,    2, 0x08,  101 /* Private */,
      99,    4,  759,    2, 0x08,  105 /* Private */,
     101,    3,  768,    2, 0x08,  110 /* Private */,
     108,    2,  775,    2, 0x08,  114 /* Private */,
     113,    1,  780,    2, 0x08,  117 /* Private */,
     114,    4,  783,    2, 0x08,  119 /* Private */,
     121,    1,  792,    2, 0x08,  124 /* Private */,
     122,    4,  795,    2, 0x08,  126 /* Private */,
     124,    2,  804,    2, 0x08,  131 /* Private */,
     128,    2,  809,    2, 0x08,  134 /* Private */,
     129,    1,  814,    2, 0x08,  137 /* Private */,
     130,    1,  817,    2, 0x08,  139 /* Private */,
     131,    4,  820,    2, 0x08,  141 /* Private */,
     134,    2,  829,    2, 0x08,  146 /* Private */,
     135,    3,  834,    2, 0x08,  149 /* Private */,
     137,    2,  841,    2, 0x08,  153 /* Private */,
     138,    3,  846,    2, 0x08,  156 /* Private */,
     143,    0,  853,    2, 0x08,  160 /* Private */,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 41,   42,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 41,   42,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 41,   42,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 41,   42,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 41,   42,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 41,   42,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 41,   42,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 41,   42,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 82, 0x80000000 | 84, 0x80000000 | 86,   83,   85,   87,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 82, 0x80000000 | 84, 0x80000000 | 86,   83,   85,   87,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 86, 0x80000000 | 97, 0x80000000 | 98,   87,   83,   85,
    QMetaType::Void, 0x80000000 | 86, 0x80000000 | 41, 0x80000000 | 84, QMetaType::Int,   87,   42,   85,  100,
    QMetaType::Void, 0x80000000 | 102, 0x80000000 | 104, 0x80000000 | 106,  103,  105,  107,
    QMetaType::Void, 0x80000000 | 109, 0x80000000 | 111,  110,  112,
    QMetaType::Void, 0x80000000 | 104,  105,
    0x80000000 | 115, 0x80000000 | 116, 0x80000000 | 104, QMetaType::QString, 0x80000000 | 119,  117,  105,  118,  120,
    QMetaType::Void, 0x80000000 | 104,  105,
    0x80000000 | 119, 0x80000000 | 116, 0x80000000 | 104, QMetaType::QString, 0x80000000 | 119,  123,  105,  118,  120,
    0x80000000 | 125, QMetaType::Int, 0x80000000 | 98,  126,  127,
    0x80000000 | 119, QMetaType::Int, 0x80000000 | 98,  126,  127,
    QMetaType::Int, 0x80000000 | 97,   83,
    QMetaType::Int, 0x80000000 | 116,  123,
    QMetaType::Void, 0x80000000 | 119, 0x80000000 | 84, 0x80000000 | 82, 0x80000000 | 125,  132,   85,   83,  133,
    QMetaType::Void, 0x80000000 | 119, 0x80000000 | 84,   42,   85,
    QMetaType::Bool, 0x80000000 | 119, 0x80000000 | 82, 0x80000000 | 119,   42,   83,  136,
    QMetaType::Void, 0x80000000 | 119, 0x80000000 | 84,   42,   85,
    QMetaType::Void, QMetaType::Int, 0x80000000 | 111, 0x80000000 | 141,  139,  140,  142,
    QMetaType::Void,

       0        // eod
};

Q_CONSTINIT const QMetaObject MainWindow::staticMetaObject = { {
    QMetaObject::SuperData::link<QMainWindow::staticMetaObject>(),
    qt_meta_stringdata_CLASSMainWindowENDCLASS.offsetsAndSizes,
    qt_meta_data_CLASSMainWindowENDCLASS,
    qt_static_metacall,
    nullptr,
    qt_incomplete_metaTypeArray<qt_meta_stringdata_CLASSMainWindowENDCLASS_t,
        // Q_OBJECT / Q_GADGET
        QtPrivate::TypeAndForceComplete<MainWindow, std::true_type>,
        // method 'showMainPage'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'showDropOffPage'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'showSearchPage'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'showCustomerSearchResultsPage'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'showNewCustomerPage'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'showOrderLaundryPage'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'showOrderDryCleanPage'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'showOrderAlterationsPage'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'showPickUpPage'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'showCustomerSearchPagePU'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'showOrderSearchPagePU'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'showCustomerSearchResultsPU'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'showOrderSearchResultsPU'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'showEditOrderPage'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'showOrderSearchPageEO'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'showCustomerSearchPageEO'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'showCustomerSearchResultsEO'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'showOrderSearchResultsEO'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'showAdminPage'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'showItemsAndPricePage'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_btnDropOff_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_btnPickUp_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_btnEditOrder_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_btnAdmin_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_btnLaundry_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_btnDryClean_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_btnAlterations_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_btnCustomer_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_btnReturn_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_btnSaveDP_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_btnOneRecieptDP_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_btnTwoRecieptDP_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_btnReturnCS_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_btnNewCustomersCS_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_btnReturn_3_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_btnCreate_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_btnReturnCSR_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_btnSearchCS_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_tableViewCSR_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QModelIndex &, std::false_type>,
        // method 'clearScreenNC'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_btnLaundryReturn_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_tableWidgetLaundryOptions_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QModelIndex &, std::false_type>,
        // method 'on_btnDryCleanReturn_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_tableWidgetDryCleanOptions_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QModelIndex &, std::false_type>,
        // method 'on_btnAlterationsReturn_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_tableWidgetAlterationsOptions_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QModelIndex &, std::false_type>,
        // method 'on_btnCustomerPU_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_btnOrderSearchPU_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_btnSavePU_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_btnReturnPU_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_btnReturnCSPU_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_btnSearchCSPU_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_btnReturnOS_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_btnSearchOrderOS_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_btnReturnCSRPU_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_tableViewCSRPU_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QModelIndex &, std::false_type>,
        // method 'on_btnReturnOSR_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_tableViewOSR_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QModelIndex &, std::false_type>,
        // method 'on_btnCustomerEO_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_btnOrderSearchEO_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_btnSaveEO_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_btnOneRecieptEO_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_btnTwoRecieptEO_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_btnReturnEO_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_btnReturnOSEO_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_btnSearchOrderEO_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_btnReturnCSEO_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_btnSearchCSEO_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_btnReturnCSREO_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_tableViewCSREO_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QModelIndex &, std::false_type>,
        // method 'on_btnReturnOSREO_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_tableViewOSREO_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QModelIndex &, std::false_type>,
        // method 'on_btnReturnAP_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_btnCIP_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_btnExportData_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_btnReturnCIP_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_btnSaveCIP_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'saveTableCIP'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<std::vector<std::vector<std::pair<std::string,double>> > &, std::false_type>,
        QtPrivate::TypeAndForceComplete<std::vector<std::tuple<std::string,int,int>> &, std::false_type>,
        QtPrivate::TypeAndForceComplete<QTableWidget *, std::false_type>,
        // method 'setUpCIPPage'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'setUpTableWidgetsCIP'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<std::vector<std::vector<std::pair<std::string,double>> > &, std::false_type>,
        QtPrivate::TypeAndForceComplete<std::vector<std::tuple<std::string,int,int>> &, std::false_type>,
        QtPrivate::TypeAndForceComplete<QTableWidget *, std::false_type>,
        // method 'clearScreenDP'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'clearScreenPU'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'clearScreenEO'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'updateCOInformationDP'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'updateCOInformationPU'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'updateCOInformationEO'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'setUpOptionsTables'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<QTableWidget *, std::false_type>,
        QtPrivate::TypeAndForceComplete<std::vector<std::vector<std::pair<std::string,double>> >, std::false_type>,
        QtPrivate::TypeAndForceComplete<std::vector<std::tuple<std::string,int,int>>, std::false_type>,
        // method 'tableWidgetOptions'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<QTableWidget *, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QModelIndex &, std::false_type>,
        QtPrivate::TypeAndForceComplete<std::vector<std::tuple<std::string,int,int>> &, std::false_type>,
        QtPrivate::TypeAndForceComplete<int, std::false_type>,
        // method 'customerSearchPageSetUp'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<QTableView *, std::false_type>,
        QtPrivate::TypeAndForceComplete<QStandardItemModel *, std::false_type>,
        QtPrivate::TypeAndForceComplete<QLineEdit *, std::false_type>,
        // method 'setDate'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<QDateTimeEdit *, std::false_type>,
        QtPrivate::TypeAndForceComplete<QDateEdit *, std::false_type>,
        // method 'saveModel'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<QStandardItemModel *, std::false_type>,
        // method 'saveTableView'
        QtPrivate::TypeAndForceComplete<std::pair<size_t,std::vector<std::vector<std::tuple<std::string,int,double>> >>, std::false_type>,
        QtPrivate::TypeAndForceComplete<std::vector<std::vector<std::tuple<std::string,int,double>> >, std::false_type>,
        QtPrivate::TypeAndForceComplete<QStandardItemModel *, std::false_type>,
        QtPrivate::TypeAndForceComplete<QString, std::false_type>,
        QtPrivate::TypeAndForceComplete<size_t, std::false_type>,
        // method 'updateModel'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<QStandardItemModel *, std::false_type>,
        // method 'updateTableView'
        QtPrivate::TypeAndForceComplete<size_t, std::false_type>,
        QtPrivate::TypeAndForceComplete<std::vector<std::vector<std::tuple<std::string,int,double>> >, std::false_type>,
        QtPrivate::TypeAndForceComplete<QStandardItemModel *, std::false_type>,
        QtPrivate::TypeAndForceComplete<QString, std::false_type>,
        QtPrivate::TypeAndForceComplete<size_t, std::false_type>,
        // method 'getTypeName'
        QtPrivate::TypeAndForceComplete<std::string, std::false_type>,
        QtPrivate::TypeAndForceComplete<int, std::false_type>,
        QtPrivate::TypeAndForceComplete<std::vector<std::tuple<std::string,int,int>>, std::false_type>,
        // method 'getIndex'
        QtPrivate::TypeAndForceComplete<size_t, std::false_type>,
        QtPrivate::TypeAndForceComplete<int, std::false_type>,
        QtPrivate::TypeAndForceComplete<std::vector<std::tuple<std::string,int,int>>, std::false_type>,
        // method 'calculateSize'
        QtPrivate::TypeAndForceComplete<int, std::false_type>,
        QtPrivate::TypeAndForceComplete<std::vector<std::vector<std::pair<std::string,double>> >, std::false_type>,
        // method 'calculatePieceTotal'
        QtPrivate::TypeAndForceComplete<int, std::false_type>,
        QtPrivate::TypeAndForceComplete<std::vector<std::vector<std::tuple<std::string,int,double>> >, std::false_type>,
        // method 'createType'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<size_t, std::false_type>,
        QtPrivate::TypeAndForceComplete<std::vector<std::tuple<std::string,int,int>> &, std::false_type>,
        QtPrivate::TypeAndForceComplete<std::vector<std::vector<std::pair<std::string,double>> > &, std::false_type>,
        QtPrivate::TypeAndForceComplete<std::string, std::false_type>,
        // method 'increaseIndex'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<size_t, std::false_type>,
        QtPrivate::TypeAndForceComplete<std::vector<std::tuple<std::string,int,int>> &, std::false_type>,
        // method 'removeItemPrice'
        QtPrivate::TypeAndForceComplete<bool, std::false_type>,
        QtPrivate::TypeAndForceComplete<size_t, std::false_type>,
        QtPrivate::TypeAndForceComplete<std::vector<std::vector<std::pair<std::string,double>> > &, std::false_type>,
        QtPrivate::TypeAndForceComplete<size_t, std::false_type>,
        // method 'removeIndex'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<size_t, std::false_type>,
        QtPrivate::TypeAndForceComplete<std::vector<std::tuple<std::string,int,int>> &, std::false_type>,
        // method 'saveAndPrint'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<int, std::false_type>,
        QtPrivate::TypeAndForceComplete<QDateEdit *, std::false_type>,
        QtPrivate::TypeAndForceComplete<QCheckBox *, std::false_type>,
        // method 'printReciept'
        QtPrivate::TypeAndForceComplete<void, std::false_type>
    >,
    nullptr
} };

void MainWindow::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<MainWindow *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->showMainPage(); break;
        case 1: _t->showDropOffPage(); break;
        case 2: _t->showSearchPage(); break;
        case 3: _t->showCustomerSearchResultsPage(); break;
        case 4: _t->showNewCustomerPage(); break;
        case 5: _t->showOrderLaundryPage(); break;
        case 6: _t->showOrderDryCleanPage(); break;
        case 7: _t->showOrderAlterationsPage(); break;
        case 8: _t->showPickUpPage(); break;
        case 9: _t->showCustomerSearchPagePU(); break;
        case 10: _t->showOrderSearchPagePU(); break;
        case 11: _t->showCustomerSearchResultsPU(); break;
        case 12: _t->showOrderSearchResultsPU(); break;
        case 13: _t->showEditOrderPage(); break;
        case 14: _t->showOrderSearchPageEO(); break;
        case 15: _t->showCustomerSearchPageEO(); break;
        case 16: _t->showCustomerSearchResultsEO(); break;
        case 17: _t->showOrderSearchResultsEO(); break;
        case 18: _t->showAdminPage(); break;
        case 19: _t->showItemsAndPricePage(); break;
        case 20: _t->on_btnDropOff_clicked(); break;
        case 21: _t->on_btnPickUp_clicked(); break;
        case 22: _t->on_btnEditOrder_clicked(); break;
        case 23: _t->on_btnAdmin_clicked(); break;
        case 24: _t->on_btnLaundry_clicked(); break;
        case 25: _t->on_btnDryClean_clicked(); break;
        case 26: _t->on_btnAlterations_clicked(); break;
        case 27: _t->on_btnCustomer_clicked(); break;
        case 28: _t->on_btnReturn_clicked(); break;
        case 29: _t->on_btnSaveDP_clicked(); break;
        case 30: _t->on_btnOneRecieptDP_clicked(); break;
        case 31: _t->on_btnTwoRecieptDP_clicked(); break;
        case 32: _t->on_btnReturnCS_clicked(); break;
        case 33: _t->on_btnNewCustomersCS_clicked(); break;
        case 34: _t->on_btnReturn_3_clicked(); break;
        case 35: _t->on_btnCreate_clicked(); break;
        case 36: _t->on_btnReturnCSR_clicked(); break;
        case 37: _t->on_btnSearchCS_clicked(); break;
        case 38: _t->on_tableViewCSR_clicked((*reinterpret_cast< std::add_pointer_t<QModelIndex>>(_a[1]))); break;
        case 39: _t->clearScreenNC(); break;
        case 40: _t->on_btnLaundryReturn_clicked(); break;
        case 41: _t->on_tableWidgetLaundryOptions_clicked((*reinterpret_cast< std::add_pointer_t<QModelIndex>>(_a[1]))); break;
        case 42: _t->on_btnDryCleanReturn_clicked(); break;
        case 43: _t->on_tableWidgetDryCleanOptions_clicked((*reinterpret_cast< std::add_pointer_t<QModelIndex>>(_a[1]))); break;
        case 44: _t->on_btnAlterationsReturn_clicked(); break;
        case 45: _t->on_tableWidgetAlterationsOptions_clicked((*reinterpret_cast< std::add_pointer_t<QModelIndex>>(_a[1]))); break;
        case 46: _t->on_btnCustomerPU_clicked(); break;
        case 47: _t->on_btnOrderSearchPU_clicked(); break;
        case 48: _t->on_btnSavePU_clicked(); break;
        case 49: _t->on_btnReturnPU_clicked(); break;
        case 50: _t->on_btnReturnCSPU_clicked(); break;
        case 51: _t->on_btnSearchCSPU_clicked(); break;
        case 52: _t->on_btnReturnOS_clicked(); break;
        case 53: _t->on_btnSearchOrderOS_clicked(); break;
        case 54: _t->on_btnReturnCSRPU_clicked(); break;
        case 55: _t->on_tableViewCSRPU_clicked((*reinterpret_cast< std::add_pointer_t<QModelIndex>>(_a[1]))); break;
        case 56: _t->on_btnReturnOSR_clicked(); break;
        case 57: _t->on_tableViewOSR_clicked((*reinterpret_cast< std::add_pointer_t<QModelIndex>>(_a[1]))); break;
        case 58: _t->on_btnCustomerEO_clicked(); break;
        case 59: _t->on_btnOrderSearchEO_clicked(); break;
        case 60: _t->on_btnSaveEO_clicked(); break;
        case 61: _t->on_btnOneRecieptEO_clicked(); break;
        case 62: _t->on_btnTwoRecieptEO_clicked(); break;
        case 63: _t->on_btnReturnEO_clicked(); break;
        case 64: _t->on_btnReturnOSEO_clicked(); break;
        case 65: _t->on_btnSearchOrderEO_clicked(); break;
        case 66: _t->on_btnReturnCSEO_clicked(); break;
        case 67: _t->on_btnSearchCSEO_clicked(); break;
        case 68: _t->on_btnReturnCSREO_clicked(); break;
        case 69: _t->on_tableViewCSREO_clicked((*reinterpret_cast< std::add_pointer_t<QModelIndex>>(_a[1]))); break;
        case 70: _t->on_btnReturnOSREO_clicked(); break;
        case 71: _t->on_tableViewOSREO_clicked((*reinterpret_cast< std::add_pointer_t<QModelIndex>>(_a[1]))); break;
        case 72: _t->on_btnReturnAP_clicked(); break;
        case 73: _t->on_btnCIP_clicked(); break;
        case 74: _t->on_btnExportData_clicked(); break;
        case 75: _t->on_btnReturnCIP_clicked(); break;
        case 76: _t->on_btnSaveCIP_clicked(); break;
        case 77: _t->saveTableCIP((*reinterpret_cast< std::add_pointer_t<std::vector<std::vector<std::pair<std::string,double>>>&>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<std::vector<std::tuple<std::string,int,int>>&>>(_a[2])),(*reinterpret_cast< std::add_pointer_t<QTableWidget*>>(_a[3]))); break;
        case 78: _t->setUpCIPPage(); break;
        case 79: _t->setUpTableWidgetsCIP((*reinterpret_cast< std::add_pointer_t<std::vector<std::vector<std::pair<std::string,double>>>&>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<std::vector<std::tuple<std::string,int,int>>&>>(_a[2])),(*reinterpret_cast< std::add_pointer_t<QTableWidget*>>(_a[3]))); break;
        case 80: _t->clearScreenDP(); break;
        case 81: _t->clearScreenPU(); break;
        case 82: _t->clearScreenEO(); break;
        case 83: _t->updateCOInformationDP(); break;
        case 84: _t->updateCOInformationPU(); break;
        case 85: _t->updateCOInformationEO(); break;
        case 86: _t->setUpOptionsTables((*reinterpret_cast< std::add_pointer_t<QTableWidget*>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<std::vector<std::vector<std::pair<std::string,double>>>>>(_a[2])),(*reinterpret_cast< std::add_pointer_t<std::vector<std::tuple<std::string,int,int>>>>(_a[3]))); break;
        case 87: _t->tableWidgetOptions((*reinterpret_cast< std::add_pointer_t<QTableWidget*>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<QModelIndex>>(_a[2])),(*reinterpret_cast< std::add_pointer_t<std::vector<std::tuple<std::string,int,int>>&>>(_a[3])),(*reinterpret_cast< std::add_pointer_t<int>>(_a[4]))); break;
        case 88: _t->customerSearchPageSetUp((*reinterpret_cast< std::add_pointer_t<QTableView*>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<QStandardItemModel*>>(_a[2])),(*reinterpret_cast< std::add_pointer_t<QLineEdit*>>(_a[3]))); break;
        case 89: _t->setDate((*reinterpret_cast< std::add_pointer_t<QDateTimeEdit*>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<QDateEdit*>>(_a[2]))); break;
        case 90: _t->saveModel((*reinterpret_cast< std::add_pointer_t<QStandardItemModel*>>(_a[1]))); break;
        case 91: { std::pair<size_t,std::vector<std::vector<std::tuple<std::string,int,double>>>> _r = _t->saveTableView((*reinterpret_cast< std::add_pointer_t<std::vector<std::vector<std::tuple<std::string,int,double>>>>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<QStandardItemModel*>>(_a[2])),(*reinterpret_cast< std::add_pointer_t<QString>>(_a[3])),(*reinterpret_cast< std::add_pointer_t<size_t>>(_a[4])));
            if (_a[0]) *reinterpret_cast< std::pair<size_t,std::vector<std::vector<std::tuple<std::string,int,double>>>>*>(_a[0]) = std::move(_r); }  break;
        case 92: _t->updateModel((*reinterpret_cast< std::add_pointer_t<QStandardItemModel*>>(_a[1]))); break;
        case 93: { size_t _r = _t->updateTableView((*reinterpret_cast< std::add_pointer_t<std::vector<std::vector<std::tuple<std::string,int,double>>>>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<QStandardItemModel*>>(_a[2])),(*reinterpret_cast< std::add_pointer_t<QString>>(_a[3])),(*reinterpret_cast< std::add_pointer_t<size_t>>(_a[4])));
            if (_a[0]) *reinterpret_cast< size_t*>(_a[0]) = std::move(_r); }  break;
        case 94: { std::string _r = _t->getTypeName((*reinterpret_cast< std::add_pointer_t<int>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<std::vector<std::tuple<std::string,int,int>>>>(_a[2])));
            if (_a[0]) *reinterpret_cast< std::string*>(_a[0]) = std::move(_r); }  break;
        case 95: { size_t _r = _t->getIndex((*reinterpret_cast< std::add_pointer_t<int>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<std::vector<std::tuple<std::string,int,int>>>>(_a[2])));
            if (_a[0]) *reinterpret_cast< size_t*>(_a[0]) = std::move(_r); }  break;
        case 96: { int _r = _t->calculateSize((*reinterpret_cast< std::add_pointer_t<std::vector<std::vector<std::pair<std::string,double>>>>>(_a[1])));
            if (_a[0]) *reinterpret_cast< int*>(_a[0]) = std::move(_r); }  break;
        case 97: { int _r = _t->calculatePieceTotal((*reinterpret_cast< std::add_pointer_t<std::vector<std::vector<std::tuple<std::string,int,double>>>>>(_a[1])));
            if (_a[0]) *reinterpret_cast< int*>(_a[0]) = std::move(_r); }  break;
        case 98: _t->createType((*reinterpret_cast< std::add_pointer_t<size_t>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<std::vector<std::tuple<std::string,int,int>>&>>(_a[2])),(*reinterpret_cast< std::add_pointer_t<std::vector<std::vector<std::pair<std::string,double>>>&>>(_a[3])),(*reinterpret_cast< std::add_pointer_t<std::string>>(_a[4]))); break;
        case 99: _t->increaseIndex((*reinterpret_cast< std::add_pointer_t<size_t>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<std::vector<std::tuple<std::string,int,int>>&>>(_a[2]))); break;
        case 100: { bool _r = _t->removeItemPrice((*reinterpret_cast< std::add_pointer_t<size_t>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<std::vector<std::vector<std::pair<std::string,double>>>&>>(_a[2])),(*reinterpret_cast< std::add_pointer_t<size_t>>(_a[3])));
            if (_a[0]) *reinterpret_cast< bool*>(_a[0]) = std::move(_r); }  break;
        case 101: _t->removeIndex((*reinterpret_cast< std::add_pointer_t<size_t>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<std::vector<std::tuple<std::string,int,int>>&>>(_a[2]))); break;
        case 102: _t->saveAndPrint((*reinterpret_cast< std::add_pointer_t<int>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<QDateEdit*>>(_a[2])),(*reinterpret_cast< std::add_pointer_t<QCheckBox*>>(_a[3]))); break;
        case 103: _t->printReciept(); break;
        default: ;
        }
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        switch (_id) {
        default: *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType(); break;
        case 77:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType(); break;
            case 2:
                *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType::fromType< QTableWidget* >(); break;
            }
            break;
        case 79:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType(); break;
            case 2:
                *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType::fromType< QTableWidget* >(); break;
            }
            break;
        case 86:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType(); break;
            case 0:
                *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType::fromType< QTableWidget* >(); break;
            }
            break;
        case 87:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType(); break;
            case 0:
                *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType::fromType< QTableWidget* >(); break;
            }
            break;
        case 88:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType(); break;
            case 2:
                *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType::fromType< QLineEdit* >(); break;
            case 1:
                *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType::fromType< QStandardItemModel* >(); break;
            case 0:
                *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType::fromType< QTableView* >(); break;
            }
            break;
        case 89:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType(); break;
            case 1:
                *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType::fromType< QDateEdit* >(); break;
            case 0:
                *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType::fromType< QDateTimeEdit* >(); break;
            }
            break;
        case 90:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType(); break;
            case 0:
                *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType::fromType< QStandardItemModel* >(); break;
            }
            break;
        case 91:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType(); break;
            case 1:
                *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType::fromType< QStandardItemModel* >(); break;
            }
            break;
        case 92:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType(); break;
            case 0:
                *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType::fromType< QStandardItemModel* >(); break;
            }
            break;
        case 93:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType(); break;
            case 1:
                *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType::fromType< QStandardItemModel* >(); break;
            }
            break;
        case 102:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType(); break;
            case 2:
                *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType::fromType< QCheckBox* >(); break;
            case 1:
                *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType::fromType< QDateEdit* >(); break;
            }
            break;
        }
    }
}

const QMetaObject *MainWindow::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *MainWindow::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_CLASSMainWindowENDCLASS.stringdata0))
        return static_cast<void*>(this);
    return QMainWindow::qt_metacast(_clname);
}

int MainWindow::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 104)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 104;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 104)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 104;
    }
    return _id;
}
QT_WARNING_POP
